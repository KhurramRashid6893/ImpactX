from __future__ import annotations

from flask import Flask, render_template, jsonify, request
import math
import requests
import datetime
import google.generativeai as genai
import json
import os
import time
from typing import List, Dict, Any, Optional
from requests_cache import CachedSession

# -----------------------------
# Flask Initialization
# -----------------------------
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-aione")

# -----------------------------
# Configuration / API Keys
# Prefer environment variables; fall back to literals you shared.
# -----------------------------

# NASA
NASA_API_KEY = os.getenv("NASA_API_KEY", "kyEL8vr6ELgMBpO0tvqWU4pUJQY6vq3VNzdcoqDv")
NEO_API_URL = "https://api.nasa.gov/neo/rest/v1/feed"

# Gemini: Rotation list (skips placeholders automatically)
GEMINI_API_KEYS: List[str] = [
    os.getenv("GEMINI_API_KEY_1", "AIzaSyBK_HgT50xaDwG22mhIXj56Nu1FLtRUn1k"),
    os.getenv("GEMINI_API_KEY_2", "AIzaSyD4WPqh0BNOGmwy9TCinChk7fffWWl5nsU"),
    os.getenv("GEMINI_API_KEY_3", "AIzaSyCix_QOd0xyagkQx81K4-mG7wgOdxm9adQ"),
    os.getenv("GEMINI_API_KEY_4", "AIzaSyBPusVyHoEU1TT2FVCQvVbpEyWTqbezAsY"),
]
DEFAULT_GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

# Weather (OpenWeatherMap) with rotation list
WEATHER_API_KEYS: List[str] = [
    os.getenv("OPENWEATHER_KEY_1", "db83f392c85c123d055ccf38a08b1bbe"),
    os.getenv("OPENWEATHER_KEY_2", "fb9b77add436ed5765d40b5e03"),
    os.getenv("OPENWEATHER_KEY_3", "PLACEHOLDER_OPENWEATHER_KEY_3"),
    os.getenv("OPENWEATHER_KEY_4", "PLACEHOLDER_OPENWEATHER_KEY_4"),
]
WEATHER_API_URL = "http://api.openweathermap.org/data/2.5/weather"

# -----------------------------
# Cache for NASA NEO (12 hours)
# -----------------------------
session = CachedSession("neo_cache", expire_after=datetime.timedelta(hours=12))

# -----------------------------
# Physics Constants
# -----------------------------
PI = 3.14159
ASTEROID_DENSITY = 3000
TARGET_DENSITY_LAND = 2700
TARGET_DENSITY_WATER = 1025
GRAVITY = 9.81
AVG_OCEAN_DEPTH = 4000
BASE_POP_DENSITY_SQKM = 150

# -----------------------------
# Helpers
# -----------------------------
def safe_float(val: Any, default: float = 0.0) -> float:
    try:
        return float(val)
    except (TypeError, ValueError):
        return default

def get_gemini_response_with_retry(prompt: str) -> str:
    """
    Try Gemini keys in order. Skip placeholders.
    Raise with a clear message if all fail.
    """
    last_error: Optional[Exception] = None

    for i, api_key in enumerate(GEMINI_API_KEYS):
        if not api_key or "PLACEHOLDER" in api_key:
            app.logger.info(f"[Gemini] Skipping placeholder/empty key at index {i}.")
            continue
        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(DEFAULT_GEMINI_MODEL)
            response = model.generate_content(prompt)
            app.logger.info(f"[Gemini] Success with key index {i}.")
            return response.text or ""
        except Exception as e:
            app.logger.warning(f"[Gemini] Error with key index {i}: {e}. Trying next...")
            last_error = e
            continue

    raise RuntimeError(f"All Gemini API keys failed. Last error: {last_error}")

def openweather_with_rotation(lat: str, lon: str, units: str = "metric") -> Dict[str, Any]:
    """
    Try OpenWeather keys in order. Rotate on 401 (Unauthorized) or 429 (Rate limit).
    Return parsed JSON weather on success, else raise a RuntimeError with details.
    """
    params_base = {"lat": lat, "lon": lon, "units": units}

    last_status = None
    last_text = None

    for i, key in enumerate(WEATHER_API_KEYS):
        if not key or "PLACEHOLDER" in key:
            app.logger.info(f"[Weather] Skipping placeholder/empty key at index {i}.")
            continue

        params = dict(params_base)
        params["appid"] = key

        try:
            resp = requests.get(WEATHER_API_URL, params=params, timeout=7)
            last_status = resp.status_code
            last_text = resp.text

            if resp.status_code == 200:
                app.logger.info(f"[Weather] Success with key index {i}.")
                return resp.json()

            if resp.status_code in (401, 429):
                app.logger.warning(
                    f"[Weather] Key index {i} returned {resp.status_code}. Rotating..."
                )
                continue

            app.logger.error(
                f"[Weather] API error {resp.status_code} with key index {i}: {resp.text[:200]}"
            )
            raise RuntimeError(
                f"Weather API error {resp.status_code}: {resp.text[:400]}"
            )

        except requests.exceptions.RequestException as e:
            app.logger.error(f"[Weather] Network error with key index {i}: {e}")
            continue

    raise RuntimeError(
        f"All OpenWeather keys failed. Last status={last_status}, body={str(last_text)[:400]}"
    )

# -----------------------------
# Page Routes
# -----------------------------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/simulation")
def simulation():
    return render_template("simulation.html")

@app.route("/impact")
def impact():
    return render_template("impact.html")

@app.route("/mitigation")
def mitigation():
    return render_template("mitigation.html")

@app.route("/resources")
def resources():
    return render_template("resources.html")

@app.route("/about")
def about():
    return render_template("about.html")

# -----------------------------
# API: NASA NEO (with cache)
# -----------------------------
@app.route("/get_neos")
def get_neos():
    """
    Fetch Near-Earth Object data from NASA NeoWs API.
    Uses requests-cache and file-backed cache as fallback.
    """
    today = datetime.date.today()
    start_date = today.strftime("%Y-%m-%d")
    end_date = (today + datetime.timedelta(days=7)).strftime("%Y-%m-%d")

    params = {"start_date": start_date, "end_date": end_date, "api_key": NASA_API_KEY}

    try:
        response = session.get(NEO_API_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        if getattr(response, "from_cache", False):
            app.logger.info("NASA NEO data served from cache.")
        else:
            app.logger.info("NASA NEO data fetched fresh and cached.")

    except requests.exceptions.RequestException as e:
        app.logger.warning(f"NASA API live fetch failed: {e}. Trying cache fallback...")
        try:
            prepared = session.prepare_request(requests.Request("GET", NEO_API_URL, params=params))
            cached_response = session.cache.get_response(prepared)
            if cached_response:
                data = json.loads(cached_response.content.decode())
                app.logger.info("NASA NEO data loaded from cache fallback.")
            else:
                return jsonify({"error": "Could not fetch live data and no cache available."}), 502
        except Exception as cache_e:
            app.logger.error(f"Cache fallback failed: {cache_e}")
            return jsonify({"error": "Could not fetch live data and cache is unavailable."}), 502

    neo_list = []
    for date_key, neos in data.get("near_earth_objects", {}).items():
        for neo in neos:
            try:
                est = neo.get("estimated_diameter", {}).get("meters", {})
                dmin = est.get("estimated_diameter_min")
                dmax = est.get("estimated_diameter_max")
                diameter_m = None
                if dmin is not None and dmax is not None:
                    diameter_m = round((float(dmin) + float(dmax)) / 2.0, 2)

                cad0 = neo.get("close_approach_data", [{}])[0]
                rel_v = cad0.get("relative_velocity", {}).get("kilometers_per_second", "0")
                velocity_km_s = round(float(rel_v), 2)

                neo_list.append({
                    "id": neo.get("id"),
                    "name": neo.get("name"),
                    "diameter_m": diameter_m,
                    "velocity_km_s": velocity_km_s,
                    "is_hazardous": bool(neo.get("is_potentially_hazardous_asteroid", False)),
                })
            except Exception:
                continue

    return jsonify(neo_list)

# -----------------------------
# API: Physics Simulation
# -----------------------------
@app.route("/simulate", methods=["POST"])
def run_simulation():
    """
    Runs the asteroid impact physics simulation.
    """
    data = request.get_json(silent=True) or {}

    diameter = safe_float(data.get("size"), 0.0)
    velocity = safe_float(data.get("speed"), 0.0) * 1000.0
    angle_deg = safe_float(data.get("angle"), 0.0)
    location = (data.get("location") or "").lower()
    impact_lat = safe_float(data.get("lat"), 0.0)
    impact_lng = safe_float(data.get("lng"), 0.0)

    angle_rad = math.radians(angle_deg)

    radius = max(diameter / 2.0, 0.0)
    volume = (4.0 / 3.0) * PI * (radius ** 3)
    mass = ASTEROID_DENSITY * volume
    kinetic_energy = 0.5 * mass * (velocity ** 2)
    energy_mt = kinetic_energy / 4.184e15

    target_density = TARGET_DENSITY_WATER if location in ("ocean", "coastal") else TARGET_DENSITY_LAND

    try:
        crater_diameter_m = (
            1.161
            * (target_density / ASTEROID_DENSITY) ** (1.0 / 3.0)
            * (diameter ** 0.78)
            * (max(velocity, 1.0) ** 0.44)
            * (max(math.sin(angle_rad), 0.1) ** (1.0 / 3.0))
        )
    except Exception:
        crater_diameter_m = 0.0

    crater_diameter_km = crater_diameter_m / 1000.0

    seismic_magnitude = 0.0
    if kinetic_energy > 0:
        try:
            seismic_magnitude = 0.67 * math.log10(kinetic_energy) - 5.87
        except Exception:
            seismic_magnitude = 0.0

    tsunami_height = 0.0
    if location in ("ocean", "coastal"):
        try:
            tsunami_height = 8.5 * (max(energy_mt, 0.0) ** 0.5) * (AVG_OCEAN_DEPTH / 4000.0) ** 0.25
        except Exception:
            tsunami_height = 0.0

    blast_radius_km = 0.0
    try:
        blast_radius_km = 3.0 * (max(energy_mt, 0.0) ** 0.33)
    except Exception:
        blast_radius_km = 0.0

    affected_population = int(PI * (blast_radius_km ** 2) * BASE_POP_DENSITY_SQKM)

    results = {
        "energy": round(energy_mt, 2),
        "crater_diameter": round(crater_diameter_km, 2),
        "seismic_magnitude": max(0.0, round(seismic_magnitude, 1)),
        "tsunami_height": round(tsunami_height, 1),
        "blast_radius": round(blast_radius_km, 2),
        "affected_population": affected_population,
        "impact_lat": impact_lat,
        "impact_lng": impact_lng,
    }

    return jsonify(results)

# -----------------------------
# API: Chatbot (Gemini with rotation)
# -----------------------------
@app.route("/chatbot", methods=["POST"])
def chatbot_api():
    """
    Handles interaction with the Gemini API for the chatbot using key rotation.
    """
    try:
        data = request.get_json(silent=True) or {}
        user_message = (data.get("message") or "").strip()

        if not user_message:
            return jsonify({"error": "Empty message"}), 400

        prompt = f"""
You are 'Sentinel AI', a friendly and professional public safety assistant for the NASA-powered 'Meteor Madness' asteroid application. Your primary goal is to provide clear, actionable advice and easily understandable facts about asteroid threats, planetary defense, and local safety precautions. Act as a resource on NEOs, impact science, and preparedness.

Keep your responses concise, encouraging, and focused on public preparedness. Always link technical terms back to real-world implications.

User Query: {user_message}
"""
        response_text = get_gemini_response_with_retry(prompt)
        return jsonify({"response": response_text})

    except Exception as e:
        app.logger.error(f"Sentinel AI Chatbot error: {e}")
        return jsonify({"error": f"Sentinel AI is offline. {e}"}), 502

# -----------------------------
# API: Impact Explanation (New Endpoint)
# -----------------------------
@app.route("/ai_explain_impact", methods=["POST"])
def ai_explain_impact():
    """
    Sends simulation results to Gemini to generate a human-readable safety summary.
    """
    try:
        data = request.get_json(silent=True) or {}

        prompt = f"""
        Analyze the following asteroid impact simulation results and generate a concise, human-readable safety advisory.
        Focus on the immediate dangers and 3-5 clear, actionable public safety steps.
        
        --- SIMULATION DATA ---
        Energy Release (MT): {data.get('energy', 'N/A')}
        Crater Diameter (km): {data.get('crater_diameter', 'N/A')}
        Seismic Magnitude (Richter): {data.get('seismic_magnitude', 'N/A')}
        Blast Radius (km): {data.get('blast_radius', 'N/A')}
        Tsunami Height (m): {data.get('tsunami_height', 'N/A')}
        Affected Population (Est.): {data.get('affected_population', 'N/A')}
        -------------------------

        ADVISORY TASK:
        1. Summarize the greatest threat (e.g., Blast, Tsunami, Seismic).
        2. State the primary danger zone size clearly in KM.
        3. Provide 3-5 steps for immediate public action.
        Keep the tone authoritative but calm. Do not use markdown.
        """
        response_text = get_gemini_response_with_retry(prompt)
        return jsonify({"advisory": response_text})

    except Exception as e:
        app.logger.error(f"AI Explainability error: {e}")
        return jsonify({"advisory": "ERROR: Could not generate safety advisory. Please check connection or API key rotation status."}), 502

# -----------------------------
# API: Weather (OpenWeather with rotation)
# -----------------------------
@app.route("/get_weather", methods=["GET"])
def get_weather():
    """
    Fetches real-time weather data for a given latitude and longitude.
    Uses OpenWeather key rotation on 401/429.
    """
    lat = request.args.get("lat")
    lon = request.args.get("lon")

    if not lat or not lon:
        return jsonify({"error": "Latitude and longitude required"}), 400

    try:
        data = openweather_with_rotation(lat=lat, lon=lon, units="metric")

        weather_data = {
            "name": data.get("name", "Unknown Location"),
            "description": (
                (data.get("weather") or [{}])[0].get("description", "unknown").capitalize()
                if data.get("weather") else "Unknown"
            ),
            "temp": (data.get("main") or {}).get("temp"),
            "humidity": (data.get("main") or {}).get("humidity"),
            "wind_speed": (data.get("wind") or {}).get("speed"),
        }
        return jsonify(weather_data)

    except RuntimeError as e:
        app.logger.error(f"Weather API error chain: {e}")
        return jsonify({"error": str(e)}), 502
    except Exception as e:
        app.logger.exception("Unexpected weather handler failure")
        return jsonify({"error": f"Unexpected error: {e}"}), 500

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    import atexit
    atexit.register(lambda: session.cache.close())
    app.run(debug=True)