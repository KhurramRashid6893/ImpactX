/**
 * Meteor Madness - Sentinel Core Script
 * Description: Manages all client-side interactions, navigation, simulation processing,
 * and Sentinel AI (Gemini Chatbot) communication across the multi-page application structure.
 *
 * This version of the script incorporates all requested features:
 * - Google Maps API for the impact map.
 * - Weather API fetching for impact location.
 * - Nominatim for reverse geocoding on Cesium globe clicks.
 * - GeoNames for population data.
 * - A hoverable modal for displaying population data details.
 */

document.addEventListener('DOMContentLoaded', function () {
    // --- Global State and Constants ---
    let neoData = [];
    let cesiumViewer = null;
    let googleMap = null;
    let impactCircles = [];
    let chatbotVisible = false;
    const defaultImpactLocation = { lat: 34.0522, lng: -118.2437 };

    // --- DOM Elements ---
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const chatbotToggle = document.querySelector('.chatbot-link');
    const chatbotContainer = document.getElementById('chatbot-container');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatbotSendBtn = document.getElementById('chatbot-send-btn');
    const chatbotMessages = document.getElementById('chatbot-messages');
    const closeChatbotBtn = document.getElementById('close-chatbot-btn');
    const chatStatus = document.getElementById('chat-status');
    const impactLatInput = document.getElementById('impact-lat');
    const impactLngInput = document.getElementById('impact-lng');
    const currentLocationCityCountry = document.getElementById('current-location-city-country');
    const currentLocationAddress = document.getElementById('current-location-address');
    let heatmap = null;

    // --- UI/Global Event Listeners ---

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            document.querySelector('.app-container').classList.toggle('sidebar-collapsed');
        });
    }

    if (chatbotToggle) {
        chatbotToggle.addEventListener('click', () => {
            chatbotVisible = !chatbotVisible;
            if (chatbotContainer) {
                chatbotContainer.style.display = chatbotVisible ? 'flex' : 'none';
            }
        });
    }

    if (closeChatbotBtn) {
        closeChatbotBtn.addEventListener('click', () => {
            chatbotVisible = false;
            if (chatbotContainer) {
                chatbotContainer.style.display = 'none';
            }
        });
    }


    // --- Page-specific Initialization ---

    const currentPage = window.location.pathname;

    function initPage() {
        if (currentPage.includes('simulation')) {
            initCesiumGlobe();
            fetchAndPopulateNEOs();
            setupSimulationControls();
        } else if (currentPage.includes('impact')) {
            initGoogleMap();
            displayImpactResults();
            setupMapOverlays();
        } else if (currentPage.includes('resources')) {
            setupResourcesPage();
        } else if (currentPage.includes('mitigation')) {
            setupMitigationControls();
        }
        updateRealTimeClock();
    }

    // --- Visualization Functions ---

    /**
     * Initializes the CesiumJS 3D globe visualization and adds click handler.
     */
    function initCesiumGlobe() {
        Cesium.Ion.defaultAccessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlOGU1MTVlNy03MDViLTRhY2MtYTVjZS0wYWMxMDY4NzM3YzAiLCJpZCI6MzQ2NjY3LCJpYXQiOjE3NTk0MjI3NzV9.-ee05zUWGmr8OiG4ib5iu7Ny8rW_NnOH1vZIAyr0Ags';
        const container = document.getElementById('cesium-container');

        if (container) {
            cesiumViewer = new Cesium.Viewer('cesium-container', {
                terrainProvider: Cesium.createWorldTerrain(),
                animation: false, timeline: false, geocoder: false, homeButton: false,
                sceneModePicker: false, baseLayerPicker: false, navigationHelpButton: false,
                infoBox: false, selectionIndicator: false, fullscreenButton: false,
            });
            
            cesiumViewer.scene.backgroundColor = Cesium.Color.fromCssColorString('#0b001a');
            cesiumViewer.scene.globe.baseColor = new Cesium.Color(0.2, 0.2, 0.4, 1);
            
            const initialPos = Cesium.Cartesian3.fromDegrees(defaultImpactLocation.lng, defaultImpactLocation.lat, 15000000);
            cesiumViewer.camera.lookAt(initialPos, new Cesium.HeadingPitchRange(0, -90 * Math.PI / 180, 25000000));

            const handler = new Cesium.ScreenSpaceEventHandler(cesiumViewer.scene.canvas);
            handler.setInputAction((click) => {
                const ray = cesiumViewer.camera.getPickRay(click.position);
                const cartesian = cesiumViewer.scene.globe.pick(ray, cesiumViewer.scene);

                if (cartesian) {
                    const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
                    const lat = Cesium.Math.toDegrees(cartographic.latitude).toFixed(4);
                    const lng = Cesium.Math.toDegrees(cartographic.longitude).toFixed(4);
                    
                    impactLatInput.value = lat;
                    impactLngInput.value = lng;
                    
                    updateCesiumMarker(lat, lng);
                }
            }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
            
            updateCesiumMarker(defaultImpactLocation.lat, defaultImpactLocation.lng);
        }
    }
    
    /**
     * Updates the Cesium viewer with a marker at the new location and reverse geocodes the name using Nominatim.
     */
    function updateCesiumMarker(lat, lng) {
        const entityId = 'impact-point-marker';
        const position = Cesium.Cartesian3.fromDegrees(lng, lat);

        const existingEntity = cesiumViewer.entities.getById(entityId);
        if (existingEntity) {
            cesiumViewer.entities.remove(existingEntity);
        }

        cesiumViewer.entities.add({
            id: entityId,
            position: position,
            point: {
                pixelSize: 15,
                color: Cesium.Color.RED,
                outlineColor: Cesium.Color.WHITE,
                outlineWidth: 3,
                disableDepthTestDistance: Number.POSITIVE_INFINITY 
            }
        });
        
        fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`)
            .then(response => response.json())
            .then(data => {
                const address = data.address;
                const locationDetails = {
                    city: address.city || address.village || address.town || address.county || 'N/A',
                    state: address.state || 'N/A',
                    country: address.country || 'N/A',
                    fullAddress: data.display_name || `Lat: ${lat}, Lng: ${lng}`
                };
                
                if (currentLocationCityCountry) {
                    currentLocationCityCountry.textContent = `${locationDetails.city}, ${locationDetails.country}`;
                }
                if (currentLocationAddress) {
                    currentLocationAddress.textContent = locationDetails.fullAddress;
                }

                const locationSelect = document.getElementById('location');
                if (locationSelect) {
                    if (locationDetails.city !== 'N/A' && locationDetails.country !== 'N/A') {
                        locationSelect.value = 'land';
                    } else {
                        locationSelect.value = 'ocean'; 
                    }
                }

            })
            .catch(error => {
                console.error("Nominatim geocoding failed:", error);
                if (currentLocationCityCountry) {
                    currentLocationCityCountry.textContent = `N/A, N/A`;
                }
                if (currentLocationAddress) {
                    currentLocationAddress.textContent = `Ocean/Remote (${lat}° N, ${lng}° E)`;
                }
            });
    }

    /**
     * Initializes the Google Maps visualization.
     */
    function initGoogleMap() {
        const container = document.getElementById('google-map-container');
        if (container && window.google) {
            const mapOptions = {
                center: { lat: 0, lng: 0 }, 
                zoom: 3,
                mapTypeId: 'satellite',
                disableDefaultUI: true,
                zoomControl: true,
                styles: [
                    { "featureType": "all", "elementType": "all", "stylers": [{ "invert_lightness": true }, { "saturation": -100 }] },
                    { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#01081a" }] }
                ]
            };
            googleMap = new google.maps.Map(container, mapOptions);
        }
    }
    
    // --- Simulation Core Logic ---

    async function fetchAndPopulateNEOs() {
        try {
            const response = await fetch('/get_neos');
            if (!response.ok) throw new Error('Failed to fetch NEO data from server');
            neoData = await response.json();
            const neoSelect = document.getElementById('neo-select');
            if (neoSelect) {
                neoSelect.innerHTML = '<option value="custom">-- Custom Scenario (Edit Inputs Below) --</option>';
                neoData.forEach(neo => {
                    const option = document.createElement('option');
                    option.value = neo.id;
                    option.textContent = `${neo.name} - ${neo.diameter_m}m ${neo.is_hazardous ? '⚠️ HAZARDOUS' : ''}`;
                    neoSelect.appendChild(option);
                });
            }
        } catch (error) {
            console.error("Error fetching NEOs:", error);
            const neoSelect = document.getElementById('neo-select');
            if (neoSelect) neoSelect.innerHTML = '<option value="custom">-- Data Offline: Use Custom Inputs --</option>';
        }
    }

    function setupSimulationControls() {
        const sizeSlider = document.getElementById('asteroid-size');
        const speedSlider = document.getElementById('asteroid-speed');
        const angleSlider = document.getElementById('impact-angle');
        const neoSelect = document.getElementById('neo-select');
        const runSimulationBtn = document.getElementById('run-simulation');
        const impactLatInput = document.getElementById('impact-lat');
        const impactLngInput = document.getElementById('impact-lng');

        const setupSlider = (slider, display, unit) => {
            if (slider && document.getElementById(display)) {
                slider.addEventListener('input', () => {
                    document.getElementById(display).textContent = `${slider.value} ${unit}`;
                    if (neoSelect) neoSelect.value = 'custom';
                });
                document.getElementById(display).textContent = `${slider.value} ${unit}`;
            }
        };

        setupSlider(sizeSlider, 'size-value', 'm');
        setupSlider(speedSlider, 'speed-value', 'km/s');
        setupSlider(angleSlider, 'angle-value', '°');

        if (neoSelect) {
            neoSelect.addEventListener('change', (event) => {
                const selectedId = event.target.value;
                if (selectedId === 'custom') return;
                const selectedNeo = neoData.find(neo => neo.id === selectedId);
                if (selectedNeo) {
                    sizeSlider.value = selectedNeo.diameter_m;
                    speedSlider.value = selectedNeo.velocity_km_s;
                    sizeSlider.dispatchEvent(new Event('input'));
                    speedSlider.dispatchEvent(new Event('input'));
                }
            });
        }

        if (runSimulationBtn) {
            runSimulationBtn.addEventListener('click', async () => {
                runSimulationBtn.textContent = 'Analyzing...';
                runSimulationBtn.disabled = true;

                const lat = parseFloat(impactLatInput.value);
                const lng = parseFloat(impactLngInput.value);
                if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                     console.error("Invalid coordinates.");
                     runSimulationBtn.textContent = 'Run Simulation & Analyze';
                     runSimulationBtn.disabled = false;
                     return;
                }

                const simulationParams = {
                    size: sizeSlider.value,
                    speed: speedSlider.value,
                    angle: angleSlider.value,
                    location: document.getElementById('location').value,
                    lat: lat,
                    lng: lng
                };
                
                try {
                    const response = await fetch('/simulate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(simulationParams)
                    });

                    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                    
                    const results = await response.json();
                    
                    localStorage.setItem('simulationResults', JSON.stringify(results));
                    window.location.href = '/impact';

                } catch (error) {
                    console.error("Simulation failed:", error);
                } finally {
                    runSimulationBtn.textContent = 'Run Simulation & Analyze';
                    runSimulationBtn.disabled = false;
                }
            });
        }
    }

    // --- Impact Page Logic ---

    function displayImpactResults() {
        const results = JSON.parse(localStorage.getItem('simulationResults'));

        const content = document.getElementById('impact-results-content');
        if (!results) {
             if (content) {
                content.innerHTML = `<section class='info-panel thought-panel'>
                    <i class='fas fa-exclamation-triangle thought-icon icon-critical'></i>
                    <div class='thought-content'>
                        <p class='thought-quote'>"No Simulation Data Found. Please run a simulation first."</p>
                        <span class='thought-source'>- System Alert</span>
                    </div>
                </section>
                <div class='warning-box module-card'><h3>⚠️ No Simulation Data</h3><p>Please run a simulation on the Simulation page first to see results.</p><a href='/simulation' class='btn btn-warning btn-primary'>Go to Simulation</a></div>`;
            }
            return;
        }

        const updateElement = (id, value) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        };

        updateElement('energy-value', `${results.energy.toLocaleString()} MT`);
        updateElement('crater-value', `${results.crater_diameter.toFixed(2)} km`);
        updateElement('seismic-value', `${results.seismic_magnitude.toFixed(1)}`);
        updateElement('blast-value', `${results.blast_radius.toFixed(2)} km`);
        updateElement('tsunami-value', `${results.tsunami_height.toFixed(1)} m`);
        updateElement('population-value', `${results.affected_population.toLocaleString()}`);

        updateImpactMap(results);
        fetchWeather(results.impact_lat, results.impact_lng);
    }
    
    async function fetchWeather(lat, lng) {
        try {
            const response = await fetch(`/get_weather?lat=${lat}&lon=${lng}`);
            if (!response.ok) throw new Error('Failed to fetch weather data.');
            const weather = await response.json();
            
            document.getElementById('weather-location').textContent = weather.name;
            document.getElementById('weather-temp').textContent = `${weather.temp}°C`;
            document.getElementById('weather-desc').textContent = weather.description;
            document.getElementById('weather-wind').textContent = `${weather.wind_speed} m/s`;
            
        } catch (error) {
            console.error("Weather data fetch failed:", error);
            document.getElementById('weather-location').textContent = `N/A (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
            document.getElementById('weather-desc').textContent = "Weather service currently offline or API key invalid.";
        }
    }

    function updateImpactMap(results) {
        if (!googleMap) initGoogleMap();
        
        const impactLatLng = { lat: results.impact_lat, lng: results.impact_lng };

        impactCircles.forEach(circle => circle.setMap(null));
        impactCircles = [];
        
        googleMap.setCenter(impactLatLng);
        googleMap.setZoom(5);

        const kmToMeters = (km) => km * 1000;

        const blastRadiusMeters = kmToMeters(results.blast_radius);
        const blastCircle = new google.maps.Circle({
            strokeColor: '#ff8c00',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#ff8c00',
            fillOpacity: 0.15,
            map: googleMap,
            center: impactLatLng,
            radius: blastRadiusMeters,
            zIndex: 1
        });
        
        const infoWindow = new google.maps.InfoWindow({
            content: `<b>Blast Radius:</b><br>${results.blast_radius.toFixed(2)} km<br><br><b>Location:</b><br>Impact Zone`
        });
        
        const marker = new google.maps.Marker({
            position: impactLatLng,
            map: googleMap,
            title: "Ground Zero",
            icon: {
                 path: google.maps.SymbolPath.CIRCLE,
                 scale: 8,
                 fillColor: '#FFFFFF',
                 fillOpacity: 1,
                 strokeWeight: 1,
                 strokeColor: '#000000',
            },
            zIndex: 3
        });

        google.maps.event.addListener(blastCircle, 'mouseover', (e) => {
             blastCircle.setOptions({fillOpacity: 0.35, strokeWeight: 4});
             infoWindow.setPosition(e.latLng);
             infoWindow.open(googleMap);
        });
        google.maps.event.addListener(blastCircle, 'mouseout', () => {
             blastCircle.setOptions({fillOpacity: 0.15, strokeWeight: 2});
             infoWindow.close();
        });
        
        impactCircles.push(blastCircle);

        const craterRadiusMeters = kmToMeters(results.crater_diameter / 2);
        const craterCircle = new google.maps.Circle({
            strokeColor: '#e81d1d',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#e81d1d',
            fillOpacity: 0.5,
            map: googleMap,
            center: impactLatLng,
            radius: craterRadiusMeters,
            zIndex: 2
        });
        impactCircles.push(craterCircle);
        impactCircles.push(marker);

        if (results.tsunami_height > 0) {
            const tsunamiCircle = new google.maps.Circle({
                strokeColor: '#3a82f7',
                strokeOpacity: 0.4,
                strokeWeight: 1,
                fillColor: '#3a82f7',
                fillOpacity: 0.1,
                map: googleMap,
                center: impactLatLng,
                radius: 200000, 
                zIndex: 0
            });
             impactCircles.push(tsunamiCircle);
        }

        const bounds = new google.maps.LatLngBounds();
        bounds.extend(blastCircle.getBounds().getNorthEast());
        bounds.extend(blastCircle.getBounds().getSouthWest());
        googleMap.fitBounds(bounds);
        
    }

    // --- Mitigation Page Logic ---
    function setupMitigationControls() {
        const simulateButtons = document.querySelectorAll('.mitigation-card .btn-simulate');
        simulateButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const strategy = btn.closest('.mitigation-card').querySelector('h3').textContent;
                console.log(`Simulation initiated for ${strategy}`);
            });
        });
    }

    // --- Resources Page Logic ---
    function setupResourcesPage() {
        const explainImpactBtn = document.getElementById('explain-impact-btn');
        const aiResponseContainer = document.getElementById('ai-response-container');
        const simulationResults = localStorage.getItem('simulationResults');
        
        if (simulationResults) {
            explainImpactBtn.disabled = false;
            aiResponseContainer.innerHTML = `<p class="no-data-message">Click 'Explain Last Impact' to get a safety advisory.</p>`;

            explainImpactBtn.addEventListener('click', async () => {
                explainImpactBtn.disabled = true;
                explainImpactBtn.textContent = 'Generating Advisory...';
                aiResponseContainer.innerHTML = `<p class="no-data-message">Generating...</p>`;
                
                try {
                    const response = await fetch('/ai_explain_impact', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: simulationResults
                    });
                    
                    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                    
                    const data = await response.json();
                    if (data.advisory) {
                        aiResponseContainer.innerHTML = `<p>${data.advisory}</p>`;
                    } else {
                        throw new Error('No advisory received.');
                    }
                } catch (error) {
                    console.error("Failed to fetch AI advisory:", error);
                    aiResponseContainer.innerHTML = `<p class="no-data-message">Error: Failed to generate advisory. Please try again or check API connection.</p>`;
                } finally {
                    explainImpactBtn.disabled = false;
                    explainImpactBtn.textContent = 'Explain Last Impact';
                }
            });
        }
    }


    // --- Sentinel AI Chatbot Logic ---
    // Moved to the footer for consistency across all pages
    const chatbotLink = document.querySelector('.chatbot-link');
    if (chatbotLink) {
        chatbotLink.addEventListener('click', () => {
            chatbotVisible = !chatbotVisible;
            if (chatbotContainer) {
                chatbotContainer.style.display = chatbotVisible ? 'flex' : 'none';
            }
        });
    }

    if (closeChatbotBtn) {
        closeChatbotBtn.addEventListener('click', () => {
            chatbotVisible = false;
            if (chatbotContainer) {
                chatbotContainer.style.display = 'none';
            }
        });
    }

    if (chatbotSendBtn) {
        chatbotSendBtn.addEventListener('click', sendMessage);
    }
    if (chatbotInput) {
        chatbotInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }

    async function sendMessage() {
        const message = chatbotInput.value.trim();
        if (message === '') return;

        appendMessage('user', message);
        chatbotInput.value = '';
        chatStatus.textContent = "Sentinel AI is typing...";
        
        const loadingMessage = appendMessage('ai', '...');
        loadingMessage.classList.add('loading-placeholder');

        try {
            const response = await fetch('/chatbot', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: message })
            });

            if (!response.ok) throw new Error('Server returned an error for the chatbot request.');

            const data = await response.json();
            
            loadingMessage.classList.remove('loading-placeholder');
            loadingMessage.textContent = data.response;

        } catch (error) {
            console.error("Sentinel AI communication failed:", error);
            loadingMessage.classList.remove('loading-placeholder');
            loadingMessage.textContent = "Sentinel AI: Connection interrupted. Please check your network.";
        } finally {
            chatStatus.textContent = "Online";
            chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
        }
    }

    function appendMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', sender === 'user' ? 'user-message' : 'ai-message');
        
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        contentDiv.textContent = text;

        const iconDiv = document.createElement('div');
        iconDiv.classList.add('message-icon');
        iconDiv.innerHTML = sender === 'user' ? '<i class="fas fa-user-astronaut"></i>' : '<i class="fas fa-robot"></i>';

        messageDiv.appendChild(iconDiv);
        messageDiv.appendChild(contentDiv);
        
        chatbotMessages.appendChild(messageDiv);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;

        return contentDiv;
    }

    function updateRealTimeClock() {
        const timeElement = document.getElementById('system-time');
        const dateElement = document.getElementById('system-date');
        const options = {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
            hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false
        };

        function update() {
            const now = new Date();
            const formattedTime = now.toLocaleTimeString('en-US', { hour12: false });
            const formattedDate = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
            
            if (timeElement) timeElement.textContent = `UTC: ${now.getUTCHours()}:${now.getUTCMinutes().toString().padStart(2, '0')}:${now.getUTCSeconds().toString().padStart(2, '0')}`;
            if (dateElement) dateElement.textContent = `${formattedDate}`;
        }

        setInterval(update, 1000);
        update(); // Initial call
    }
    initPage();
});